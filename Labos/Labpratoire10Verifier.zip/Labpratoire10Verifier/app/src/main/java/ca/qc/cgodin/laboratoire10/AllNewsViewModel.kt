package ca.qc.cgodin.laboratoire10

import androidx.lifecycle.ViewModel

class AllNewsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}