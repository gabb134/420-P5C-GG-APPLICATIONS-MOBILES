package ca.qc.cgodin.laboratoire10

import androidx.lifecycle.ViewModel

class ArticleViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}