package ca.qc.cgodin.laboratoire10

import androidx.lifecycle.ViewModel

class SavedNewsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}