package ca.qc.godin.laboratoire2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class DestinataireActivity : AppCompatActivity() {
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_destinataire)
    }
}