package ca.qc.cgodin.labo7contentproviderrecyclerview

import android.graphics.Bitmap

class Contact(val fullName: String, val phoneNumber: String, var image: Bitmap? = null)